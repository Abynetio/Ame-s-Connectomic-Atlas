
load C_BM.mat;
C = C_BM;
labels = labels_BM;
tree = linkage(C,'weighted','spearman');
threshold = 0.63;



dendrogram(tree,0,'Orientation','right','ColorThreshold',threshold);
orders = str2num(get(gca,'YTickLabel'));

r_matrix = corr(C(orders,:)','Type','Spearman');
imagesc(1-r_matrix)
set(gca,'Ytick',1:180,'YTickLabel',labels(orders));
set(gca,'Xtick',1:180,'XTickLabel',labels(orders));
xtickangle(90)
set(gca,'XAxisLocation','top');
colormap(gray);

set(gcf, 'PaperSize', [10 10]);
set(gcf, 'PaperPosition', [0 0 10 10]);  
print(gcf,'-dtiff','-r300','region_r_BM.tif');



H = dendrogram(tree,0,'Orientation','top','Labels',labels,'ColorThreshold',threshold);
set(gca,'ytick',[]);
h = gca; h.YAxis.Visible = 'off';
xtickangle(90)
set(gca,'TickLength',[0 0])
set(gca,'FontSize',5)

% handle color
colors = zeros(38,1);
for i = 1:38
   c = int32(H(i).Color*255);
   colors(i) = c(1)*256*256+c(2)*256+c(3);
end

% assign new color based on first cortical region
group_id = [1 6 11 15 20 27 30 35];
new_color = [
250 174 96;...
175 250 100;...
108 255 185;...
202 104 252;...
227 88 88;...
16 159 88;...
101 101 250;...
250 96 147;...
];

for i = 1:length(group_id)
    j = mod(find(tree == orders(group_id(i))),38);
    pos = find(colors == colors(j));
    for k = 1:length(pos)
        H(pos(k)).Color = new_color(i,:)/255.0';
    end
end
set(gcf, 'PaperSize', [6 1.5]);
set(gcf, 'PaperPosition', [0 0 6 1.5]);  
print(gcf,'-dtiff','-r600','top_BM.tif');

orders = orders(end:-1:1);

rank(orders) = 1:39;
rank = rank';

new_label_order = labels(orders);
new_C = C(orders,:);

