
load C_MMP.mat;
tree = linkage(C,'weighted','spearman');
threshold = 0.56;



dendrogram(tree,0,'Orientation','right','ColorThreshold',threshold);
orders = str2num(get(gca,'YTickLabel'));

r_matrix = corr(C(orders,:)','Type','Spearman');
imagesc(r_matrix)
set(gca,'Ytick',1:180,'YTickLabel',labels(orders));
set(gca,'Xtick',1:180,'XTickLabel',labels(orders));
xtickangle(90)
set(gca,'XAxisLocation','top');
colormap(jet);

set(gcf, 'PaperSize', [20 20]);
set(gcf, 'PaperPosition', [0 0 20 20]);  
print(gcf,'-dtiff','-r300','region_r.tif');

orders = orders(end:-1:1);

H = dendrogram(tree,0,'Orientation','top','Labels',labels,'ColorThreshold',threshold);
set(gca,'ytick',[]);
h = gca; h.YAxis.Visible = 'off';
xtickangle(90)
set(gca,'TickLength',[0 0])
set(gca,'FontSize',5)

% handle color
colors = zeros(179,1);
for i = 1:179
   c = int32(H(i).Color*255);
   colors(i) = c(1)*256*256+c(2)*256+c(3);
end

% assign new color based on first cortical region
group_id = [1 9 15 34 48 55 63 77 107 114 126 136 150 154 158];
new_color = [
250 103 152;...
250 103 201;...
201 103 250;...
103 226 250;...
150 0 75;...
103 103 250;...
103 250 177;...
250 177 103;...
103 250 103;...
177 250 103;...
76 150 1;...
1 150 76;...
200 101 2;...
150 0 0;...
250 103 103];

for i = 1:length(group_id)
    j = mod(find(tree == orders(group_id(i))),179);
    pos = find(colors == colors(j));
    for k = 1:length(pos)
        H(pos(k)).Color = new_color(i,:)/255.0';
    end
end

set(gcf, 'PaperSize', [12 3]);
set(gcf, 'PaperPosition', [0 0 12 3]);  
print(gcf,'-dtiff','-r600','top.tif');



rank(orders) = 1:180;
rank = rank';

new_label_order = labels(orders);
new_C = C(orders,:);

