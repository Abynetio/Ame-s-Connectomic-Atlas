load C.mat;
t=[1 2 3 4 5 6 13 14 15 16 18 19 20 21 25 26];
% t= 1:26;


tree_left = linkage(C(:,t)','weighted','spearman');
tree_right = linkage(C(:,t+26)','weighted','spearman');

tree_left_BM = linkage(C_BM(:,t)','weighted','spearman');
tree_right_BM = linkage(C_BM(:,t+26)','weighted','spearman');

tree_left_KL = linkage(C_KL(:,t)','weighted','spearman');
tree_right_KL = linkage(C_KL(:,t+26)','weighted','spearman');


oo_right = [12,3,6,2,4,5,8,15,9,16,11,10,1,14,13,7];
dendrogram(tree_left,0,'Orientation','right','ColorThreshold',0.9,'reorder',oo_right);
orders_left = str2num(get(gca,'YTickLabel'));
orders_left = orders_left(end:-1:1);
dendrogram(tree_right,0,'Orientation','right','ColorThreshold',0.9,'reorder',oo_right);
orders_right = str2num(get(gca,'YTickLabel'));
orders_right = orders_right(end:-1:1);

r_left = corr(C(:,t(orders_left)),'Type','Spearman');
r_left(r_left < 0) = 0;
imagesc(r_left);
colormap(flipud(gray));
set(gca,'Ytick',1:16,'YTickLabel',flipud(track_labels(t(oo_right))));
set(gca,'xtick',[])


set(gcf, 'PaperSize', [5 4.7]);
set(gcf, 'PaperPosition', [0 0 5 4.7]);  
print(gcf,'-dtiff','-r600','r_left.tif'); 

r_right = corr(C(:,t(orders_right)+26),'Type','Spearman');
r_right(r_right < 0) = 0;
imagesc(r_right);
colormap(flipud(gray));
set(gca,'xtick',[])
set(gca, 'YAxisLocation', 'right')
set(gca,'Ytick',1:16,'YTickLabel',flipud(track_labels(t(oo_right))));

set(gcf, 'PaperSize', [5 4.7]);
set(gcf, 'PaperPosition', [0 0 5 4.7]);  
print(gcf,'-dtiff','-r600','r_right.tif'); 

[H,T,outperm] = dendrogram(tree_left,0,'Orientation','right','Labels',track_labels(t),'ColorThreshold',0.9,'reorder',oo_right);
set(gca,'xtick',[])
set(gca,'TickLength',[0 0])
set(gca,'FontSize',3)
for i = 1:15
   c = H(i).Color;    
   c = c*0.6;
   H(i).Color = c;    
end

c1 = H(4).Color;
c2 = H(8).Color;
H(8).Color = c1;
H(4).Color = c2;
H(7).Color = c2;
H(9).Color = c2;


h = gca; h.XAxis.Visible = 'off';
set(gcf, 'PaperSize', [0.5 2]);
set(gcf, 'PaperPosition', [0 0 0.5 2]);  
print(gcf,'-dtiff','-r600','tracks_left.tif'); 


[H,T,outperm] = dendrogram(tree_right,0,'Orientation','left','Labels',track_labels(t),'ColorThreshold',0.9,'reorder',oo_right);
set(gca,'xtick',[])
set(gca,'TickLength',[0 0])
set(gca,'FontSize',3)

for i = 1:15
   c = H(i).Color;    
   c = c*0.6;
   H(i).Color = c;    
end
h = gca; h.XAxis.Visible = 'off';
set(gcf, 'PaperSize', [0.5 2]);
set(gcf, 'PaperPosition', [0 0 0.5 2]);  
print(gcf,'-dtiff','-r600','tracks_right.tif'); 

